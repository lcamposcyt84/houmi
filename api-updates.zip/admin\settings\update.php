<?php
// update.php - Update store settings
require_once dirname(dirname(__DIR__)) . '/db.php';
require_once dirname(__DIR__) . '/auth.php';

$admin = requireAdminAuth();

if ($_SERVER['REQUEST_METHOD'] !== 'PUT' && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit();
}

$data = json_decode(file_get_contents("php://input"));

try {
    $fields = [];
    $params = [];

    if (isset($data->exchangeRateUsdToVes)) {
        $fields[] = "exchangeRateUsdToVes = :rate";
        $params[':rate'] = (float)$data->exchangeRateUsdToVes;
    }
    if (isset($data->storeName)) {
        $fields[] = "storeName = :name";
        $params[':name'] = $data->storeName;
    }
    if (isset($data->storeDescription)) {
        $fields[] = "storeDescription = :desc";
        $params[':desc'] = $data->storeDescription;
    }
    if (isset($data->whatsappNumber)) {
        $fields[] = "whatsappNumber = :whatsapp";
        $params[':whatsapp'] = $data->whatsappNumber;
    }
    if (isset($data->mercantilApiUrl)) {
        $fields[] = "mercantilApiUrl = :mUrl";
        $params[':mUrl'] = $data->mercantilApiUrl;
    }
    if (isset($data->mercantilApiPath)) {
        $fields[] = "mercantilApiPath = :mPath";
        $params[':mPath'] = $data->mercantilApiPath;
    }
    if (isset($data->mercantilApiKey)) {
        $fields[] = "mercantilApiKey = :mKey";
        $params[':mKey'] = $data->mercantilApiKey;
    }
    if (isset($data->mercantilApiSecret)) {
        $fields[] = "mercantilApiSecret = :mSecret";
        $params[':mSecret'] = $data->mercantilApiSecret;
    }
    if (isset($data->mercantilMasterKey)) {
        $fields[] = "mercantilMasterKey = :mMaster";
        $params[':mMaster'] = $data->mercantilMasterKey;
    }
    if (isset($data->mercantilIdComercio)) {
        $fields[] = "mercantilIdComercio = :mId";
        $params[':mId'] = $data->mercantilIdComercio;
    }
    if (isset($data->mercantilWebhookUrl)) {
        $fields[] = "mercantilWebhookUrl = :mWebhook";
        $params[':mWebhook'] = $data->mercantilWebhookUrl;
    }

    if (empty($fields)) {
        http_response_code(400);
        echo json_encode(['error' => 'No hay campos para actualizar']);
        exit();
    }

    $fields[] = "updatedAt = NOW()";
    $sql = "UPDATE Settings SET " . implode(', ', $fields) . " WHERE id = 'main'";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    // Return updated settings
    $getStmt = $pdo->query("SELECT * FROM Settings WHERE id = 'main'");
    $settings = $getStmt->fetch();

    echo json_encode([
        'success' => true,
        'settings' => [
            'id' => $settings['id'],
            'exchangeRateUsdToVes' => (float)$settings['exchangeRateUsdToVes'],
            'storeName' => $settings['storeName'],
            'storeDescription' => $settings['storeDescription'],
            'whatsappNumber' => $settings['whatsappNumber'],
            'mercantilApiUrl' => $settings['mercantilApiUrl'],
            'mercantilApiPath' => $settings['mercantilApiPath'],
            'mercantilApiKey' => $settings['mercantilApiKey'],
            'mercantilApiSecret' => $settings['mercantilApiSecret'],
            'mercantilMasterKey' => $settings['mercantilMasterKey'],
            'mercantilIdComercio' => $settings['mercantilIdComercio'],
            'mercantilWebhookUrl' => $settings['mercantilWebhookUrl'],
            'updatedAt' => $settings['updatedAt']
        ]
    ]);

} catch (\PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error', 'details' => $e->getMessage()]);
}
?>
