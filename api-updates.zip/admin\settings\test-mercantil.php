<?php
// test-mercantil.php - Test Mercantil API connection
require_once dirname(dirname(__DIR__)) . '/db.php';
require_once dirname(__DIR__) . '/auth.php';

$admin = requireAdminAuth();

try {
    $stmt = $pdo->query("SELECT mercantilApiUrl, mercantilApiPath, mercantilApiKey, mercantilApiSecret, mercantilIdComercio FROM Settings WHERE id = 'main'");
    $settings = $stmt->fetch();

    if (!$settings || empty($settings['mercantilApiUrl']) || empty($settings['mercantilApiKey'])) {
        echo json_encode(['ok' => false, 'message' => 'API de Mercantil no configurada', 'detail' => 'Configura los datos del banco en Ajustes']);
        exit();
    }

    $apiUrl = rtrim($settings['mercantilApiUrl'], '/');
    $apiPath = $settings['mercantilApiPath'] ?: '/api';
    $fullUrl = $apiUrl . $apiPath;

    $ch = curl_init($fullUrl);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'X-IBM-Client-Id: ' . $settings['mercantilApiKey'],
            'Accept: application/json',
        ],
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($curlError) {
        echo json_encode(['ok' => false, 'message' => 'Error de conexión', 'detail' => $curlError]);
        exit();
    }

    if ($httpCode >= 200 && $httpCode < 500) {
        echo json_encode(['ok' => true, 'message' => "Conexión exitosa (HTTP $httpCode)", 'detail' => mb_substr($response, 0, 500)]);
    } else {
        echo json_encode(['ok' => false, 'message' => "Respuesta inesperada (HTTP $httpCode)", 'detail' => mb_substr($response, 0, 500)]);
    }

} catch (\Exception $e) {
    echo json_encode(['ok' => false, 'message' => 'Error interno', 'detail' => $e->getMessage()]);
}
?>
