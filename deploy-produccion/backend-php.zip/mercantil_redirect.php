<?php
require_once dirname(__DIR__) . '/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit();
}

$data = json_decode(file_get_contents('php://input'));
$orderNumber = $data->orderNumber ?? null;

if (!$orderNumber) {
    http_response_code(400);
    echo json_encode(['error' => 'Número de orden requerido']);
    exit();
}

try {
    $settingsStmt = $pdo->prepare("SELECT paymentGatewayUrl, paymentMerchantId, paymentIntegratorId, paymentEncryptionKey FROM Settings WHERE id = 'main'");
    $settingsStmt->execute();
    $settings = $settingsStmt->fetch();

    $gatewayUrl = $settings['paymentGatewayUrl'] ?? '';
    $merchantId = $settings['paymentMerchantId'] ?? 'J303174043';
    $integratorId = $settings['paymentIntegratorId'] ?? '31';
    $encryptionKey = $settings['paymentEncryptionKey'] ?? '';

    if (empty($gatewayUrl)) {
        http_response_code(400);
        echo json_encode(['error' => 'Pasarela de pago no configurada']);
        exit();
    }

    $orderStmt = $pdo->prepare("SELECT * FROM Sale WHERE orderNumber = :ord");
    $orderStmt->execute([':ord' => $orderNumber]);
    $order = $orderStmt->fetch();

    if (!$order) {
        http_response_code(404);
        echo json_encode(['error' => 'Orden no encontrada']);
        exit();
    }

    // Encrypt transaction data
    $txPayload = json_encode([
        'orderId' => $order['id'],
        'orderNumber' => $orderNumber,
        'amount' => $order['totalUsd'],
        'timestamp' => time()
    ]);

    if (!empty($encryptionKey)) {
        $iv = openssl_random_pseudo_bytes(16);
        $encrypted = openssl_encrypt($txPayload, 'aes-256-cbc', substr(hash('sha256', $encryptionKey, true), 0, 32), OPENSSL_RAW_DATA, $iv);
        $transactiondata = base64_encode($iv . $encrypted);
    } else {
        $transactiondata = base64_encode($txPayload);
    }

    $separator = strpos($gatewayUrl, '?') === false ? '?' : '&';
    $redirectUrl = $gatewayUrl . $separator . http_build_query([
        'merchantid' => $merchantId,
        'transactiondata' => $transactiondata,
        'integratorid' => $integratorId
    ]);

    echo json_encode(['redirectUrl' => $redirectUrl]);

} catch (\PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error de base de datos']);
} catch (\Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
